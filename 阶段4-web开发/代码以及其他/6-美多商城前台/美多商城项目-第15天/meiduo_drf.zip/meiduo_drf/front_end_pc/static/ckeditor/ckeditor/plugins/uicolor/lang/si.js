﻿/*
 Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("uicolor","si",{title:"වර්ණ ",preview:"සජීව නැවත නරභීම",config:"මෙම අක්ෂර පේලිය ගෙන config.js ලිපිගොනුව මතින් තබන්න",predefined:"කලින් වෙන්කරගත් පරිදි ඇති වර්ණ"});